ملفات بداية لوحة تحكم أكواد التفعيل — Firebase

مهم:
- هذه الملفات تجهّز لوحة تحكم أولية لإدارة أكواد التفعيل في قاعدة Firebase.
- لا تربط ملف APK تلقائياً؛ الربط يحتاج تعديل سورس التطبيق أو وجود API يدعم التفعيل.
- لا تضع كلمة مرور أو مفتاح سري داخل ملفات HTML.
- قواعد قاعدة البيانات أدناه تقفل الوصول افتراضياً وتسمح فقط لحساب المدير المحدد.

الخطوات:
1) في Firebase Console > Authentication > Sign-in method، فعّل Email/Password.
2) من Authentication > Users، أنشئ حساب المدير وسجّل UID الخاص به.
3) افتح database.rules.json واستبدل ADMIN_UID_HERE بـ UID الحقيقي.
4) في Realtime Database > Rules، الصق محتوى database.rules.json ثم اضغط Publish.
5) افتح index.html وعدّل إعدادات firebaseConfig بقيم مشروعك من Project settings > Your apps > Web app.
6) افتح index.html عبر استضافة HTTPS (مثل Firebase Hosting)؛ فتحه كملف محلي قد لا يعمل حسب إعدادات المتصفح.

تنبيه مهم:
هذه اللوحة تسمح للمدير فقط بإدارة الأكواد. لا تجعل قراءة الأكواد متاحة للعامة. حتى يتحقق تطبيق Android من الأكواد بأمان، يجب إضافة API/Cloud Function موثوقة وربط التطبيق بها؛ لا يمكن تعديل APK وحده ليستخدم السيرفر دون معرفة/تعديل كود التطبيق.
