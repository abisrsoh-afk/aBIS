SNARE X LOADER — السورس الكامل (Android + PHP/MySQL)

المحتويات:
- android/: مشروع Android Studio بلغة Java، شاشة إدخال كود التفعيل وربط API.
- server/api/verify.php: الملف الذي يفحص كود التفعيل ويرجع valid=true أو false.
- server/api/config.php: إعدادات قاعدة بيانات MySQL (تحتاج بيانات استضافتك الحقيقية).
- server/api/create_key.php: نقطة API إدارية لإنشاء مفاتيح جديدة.
- server/sql/schema.sql: جدول قاعدة البيانات المطلوب لهذا النظام.

رابط الموقع مضبوط داخل التطبيق:
https://jssjshbw.kesug.com/api/verify.php

طريقة رفع ملفات السيرفر:
1) افتح مدير الملفات في الاستضافة ثم htdocs.
2) ارفع محتويات مجلد server إلى داخل htdocs، بحيث يصبح المسار htdocs/api/verify.php وليس htdocs/server/api/verify.php.
3) افتح server/api/config.php من السورس وعدّل DB_NAME وDB_USER وDB_PASS إلى بيانات MySQL الحقيقية من لوحة الاستضافة. لا تترك YOUR_DATABASE_NAME وغيرها كما هي.
4) أنشئ/استخدم قاعدة البيانات المطلوبة، ثم استورد server/sql/schema.sql من phpMyAdmin.
5) ملاحظة مهمة: هذا الجدول يخزن بصمة SHA-256 للمفتاح في key_hash. الأكواد القديمة التي أنشأتها بطريقة أو بجدول مختلف لن تعمل تلقائياً إلا إذا كان تخزينها متوافقاً مع هذا النظام.
6) غيّر ADMIN_TOKEN إلى قيمة سرية طويلة قبل استخدام create_key.php. لا ترسل هذا الرمز لأحد.
7) اختبر الرابط بعد ضبط قاعدة البيانات؛ مجرد وجود الرابط في التطبيق لا يعني أن السيرفر يعمل قبل رفع الملفات وضبط قاعدة البيانات.

طريقة بناء التطبيق:
افتح مجلد android في Android Studio، نفّذ Gradle Sync ثم Build APK.

تنبيه: هذا ZIP يحتوي السورس وملفات السيرفر، وليس APK جاهزاً للتثبيت. بيانات قاعدة البيانات لا يمكن تعبئتها من دون بيانات MySQL الخاصة بك.
