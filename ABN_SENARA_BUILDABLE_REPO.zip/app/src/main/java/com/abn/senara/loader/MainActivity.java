package com.abn.senara.loader;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String VALIDATE_URL = "https://jssjshbw.kesug.com/verify.php";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText codeInput;
    private Button activateButton;
    private TextView statusText;

    private int navy = Color.rgb(13, 23, 43);
    private int panel = Color.rgb(24, 36, 59);
    private int blue = Color.rgb(40, 130, 255);
    private int white = Color.WHITE;
    private int muted = Color.rgb(174, 188, 208);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(Color.BLACK);
        buildScreen();
    }

    private GradientDrawable rounded(int color, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(24f);
        d.setStroke(1, strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(navy);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(28, 40, 28, 32);
        scroll.addView(page);

        TextView title = text("ABN_SENARA_LOADER", 25, 0xFFFF8A00, true);
        page.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = text("SECURE ACCESS • ACTIVATION", 13, muted, true);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = 10;
        subLp.bottomMargin = 30;
        page.addView(subtitle, subLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(22, 24, 22, 24);
        card.setBackground(rounded(panel, 0xFF34445E));
        page.addView(card, new LinearLayout.LayoutParams(-1, -2));

        card.addView(text("أدخل كود التفعيل", 20, white, true));
        TextView hint = text("اكتب رمز التفعيل للمتابعة", 14, muted, false);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(-1, -2);
        hintLp.topMargin = 8;
        hintLp.bottomMargin = 22;
        card.addView(hint, hintLp);

        codeInput = new EditText(this);
        codeInput.setSingleLine(true);
        codeInput.setHint("XXXX-XXXX-XXXX");
        codeInput.setHintTextColor(muted);
        codeInput.setTextColor(white);
        codeInput.setPadding(18, 12, 18, 12);
        codeInput.setBackground(rounded(navy, 0xFF53647D));
        card.addView(codeInput, new LinearLayout.LayoutParams(-1, 54));

        activateButton = new Button(this);
        activateButton.setText("تحقق من كود التفعيل");
        activateButton.setTextColor(Color.WHITE);
        activateButton.setAllCaps(false);
        activateButton.setBackground(rounded(blue, blue));
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, 54);
        btnLp.topMargin = 18;
        card.addView(activateButton, btnLp);

        statusText = text("جاهز للتحقق من كود التفعيل", 14, muted, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2);
        statusLp.topMargin = 20;
        card.addView(statusText, statusLp);

        TextView footer = text("ABN SENARA • Secure Loader", 12, muted, false);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, -2);
        footLp.topMargin = 32;
        page.addView(footer, footLp);

        activateButton.setOnClickListener(v -> verifyCode());
        setContentView(scroll);
    }

    private void verifyCode() {
        String code = codeInput.getText().toString().trim();
        if (code.isEmpty()) {
            codeInput.setError("أدخل كود التفعيل");
            return;
        }
        activateButton.setEnabled(false);
        statusText.setTextColor(muted);
        statusText.setText("جارٍ الاتصال بالسيرفر...");
        executor.execute(() -> {
            HttpURLConnection connection = null;
            String response = "";
            try {
                String urlText = VALIDATE_URL + "?key=" + URLEncoder.encode(code, "UTF-8");
                connection = (HttpURLConnection) new URL(urlText).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(12000);
                int status = connection.getResponseCode();
                InputStream stream = (status >= 200 && status < 400)
                    ? connection.getInputStream() : connection.getErrorStream();
                if (stream != null) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
                    StringBuilder body = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line).append('\n');
                    reader.close();
                    response = body.toString().trim();
                }
                final String result = "HTTP " + status + (response.isEmpty() ? "" : " — " + response);
                runOnUiThread(() -> {
                    statusText.setText(result);
                    statusText.setTextColor(status >= 200 && status < 300 ? 0xFF7CFFA2 : 0xFFFFB36B);
                    activateButton.setEnabled(true);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusText.setText("تعذّر الاتصال: " + e.getClass().getSimpleName());
                    statusText.setTextColor(0xFFFF8A80);
                    activateButton.setEnabled(true);
                });
            } finally {
                if (connection != null) connection.disconnect();
            }
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        executor.shutdownNow();
    }
}
