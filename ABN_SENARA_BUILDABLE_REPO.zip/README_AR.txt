ABN_SENARA_LOADER — مشروع Android قابل للبناء عبر GitHub Actions

مهم:
- هذا مشروع Android جديد ونظيف للبناء، وليس نسخة مطابقة من APK الأصلي.
- لا يغيّر هذا الملف أي مستودع أو APK موجود عندك.
- بعد رفع محتويات هذا المجلد إلى جذر مستودع GitHub، افتح Actions وشغّل Build Android APK.
- ملف APK الناتج سيكون Debug APK للتجربة، وليس إصدار Release موقّع بمفتاحك الخاص.

طريقة الرفع من الهاتف:
1) فك ضغط ABN_SENARA_BUILDABLE_REPO.zip.
2) افتح المجلد ABN_SENARA_BUILDABLE_REPO.
3) ارفع محتوياته كلها إلى جذر مستودع جديد أو مستودع فارغ، وليس ملف ZIP نفسه فقط.
4) تأكد أن مجلد .github موجود. قد تحتاج تفعيل عرض الملفات المخفية في مدير الملفات.
5) في GitHub افتح Actions ثم Build Android APK ثم Run workflow، أو انتظر التشغيل بعد رفع الملفات.
6) عند نجاح التشغيل افتح صفحة التشغيل (workflow run) وانزل إلى Artifacts لتحميل ABN-SENARA-debug-apk.

عنوان التحقق:
https://jssjshbw.kesug.com/verify.php

ملاحظة الخادم:
الكود يرسل طلب GET بالشكل ?key=CODE. يجب أن يقبل verify.php هذا الشكل ويرجع نتيجة واضحة. إذا كان خادمك يتطلب POST أو اسم معامل مختلف، يجب تعديل MainActivity.java ليتوافق معه.

هذا المشروع يستخدم Android Gradle Plugin 8.7.3 وGradle 8.9 وJava 17.
